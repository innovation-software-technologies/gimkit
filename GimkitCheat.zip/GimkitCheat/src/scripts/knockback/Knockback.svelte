<script lang="ts">
    import Group from "../../hud/Group.svelte";
    import Rapidfire from "../shared/Rapidfire.svelte";
</script>

<Group name="Knockback">
    <Rapidfire message="Rapid fire" hotkeyId="knockbackRapidFire" />
</Group>